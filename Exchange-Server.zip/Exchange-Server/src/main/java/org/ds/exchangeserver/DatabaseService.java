package org.ds.exchangeserver;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.time.Instant;

/**
 * The {@code DatabaseService} class is responsible for logging request data
 * into a MongoDB collection named "logs" inside the "express_exchange" database.
 *
 * <p>It captures various metadata like base and target currencies, the API response,
 * client device information, IP address, and the timestamp of the request.</p>
 *
 * <p>This class also provides access to the underlying MongoCollection
 * for potential inspection or additional operations.</p>
 *
 * @author Shreyas Nopany
 * Andrew ID - snopany
 */
public class DatabaseService {

    // The MongoDB collection where logs are stored
    private final MongoCollection<Document> collection;

    /**
     * Constructor that initializes a connection to the MongoDB Atlas cluster
     * and selects the "express_exchange" database and "logs" collection.
     */
    public DatabaseService() {

        // MongoDB Atlas connection URI with authentication and cluster details
        String uri = "mongodb+srv://snopany:2RHJDobzfsDC3vu8@cluster0.negbo8a.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

        // Create a MongoClient instance using the URI
        MongoClient mongoClient = MongoClients.create(uri);

        // Access the "express_exchange" database
        MongoDatabase database = mongoClient.getDatabase("express_exchange");

        // Access the "logs" collection within the database
        collection = database.getCollection("logs");
    }

    /**
     * Logs an API request by storing relevant details in a MongoDB document.
     *
     * @param base        The base currency provided by the user.
     * @param target      The target currency requested by the user.
     * @param apiResponse The actual API response returned.
     * @param userAgent   The client's user agent string (browser/device info).
     * @param clientIp    The IP address of the client.
     */
    public void logRequest(String base, String target, String apiResponse, String userAgent, String clientIp) {

        // Create a document containing all relevant request details
        Document log = new Document("base_currency", base)
                .append("target_currency", target)
                .append("api_response", apiResponse)
                .append("timestamp", Instant.now().toString())
                .append("device_info", userAgent)
                .append("client_ip", clientIp);

        // Insert the log document into the MongoDB collection
        collection.insertOne(log);
    }

    /**
     * Getter method to access the MongoDB logs collection.
     *
     * @return The MongoCollection<Document> representing the logs.
     */
    public MongoCollection<Document> getCollection() {
        // Return the collection reference
        return collection;
    }
}
