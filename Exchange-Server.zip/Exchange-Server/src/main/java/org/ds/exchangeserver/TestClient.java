package org.ds.exchangeserver;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

/**
 * The {@code TestClient} class is a simple HTTP client that sends a POST request
 * to a local exchange server with user-specified base and target currencies,
 * then prints the server's response.
 *
 * <p>This class is useful for testing or simulating interaction with an exchange rate service
 * running locally at http://localhost:8081/exchange-server/express.</p>
 *
 * <p>Example usage:
 * <pre>
 * Enter base currency (e.g., USD): USD
 * Enter target currency (e.g., EUR): EUR
 * {"rate":0.91}
 * </pre>
 * </p>
 *
 * <p><strong>Note:</strong> Make sure the server is running at the specified URL before using this client.</p>
 *
 * @author Shreyas Nopany
 * Andrew ID - snopany
 */
public class TestClient {

    /**
     * Main method to run the test client.
     *
     * @param args Command-line arguments (not used).
     * @throws Exception if a network or I/O error occurs.
     */
    public static void main(String[] args) throws Exception {

        // Create a Scanner object to read user input from the console
        Scanner scanner = new Scanner(System.in);

        // Prompt user for the base currency (e.g., USD)
        System.out.print("Enter base currency (e.g., USD): ");

        // Read the input, remove leading/trailing whitespace, and convert to uppercase
        String base = scanner.nextLine().trim().toUpperCase();

        // Prompt user for the target currency (e.g., EUR)
        System.out.print("Enter target currency (e.g., EUR): ");

        // Read the input, remove leading/trailing whitespace, and convert to uppercase
        String target = scanner.nextLine().trim().toUpperCase();

        // Define the URL of the local exchange server endpoint
        URL url = new URL("http://localhost:8081/exchange-server/express");

        // Open an HTTP connection to the specified URL
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // Set the request method to POST for sending data
        conn.setRequestMethod("POST");

        // Set the Content-Type to application/x-www-form-urlencoded for POST form data
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        // Allow output for sending data to the server
        conn.setDoOutput(true);

        // Prepare the request parameters in URL-encoded format
        String params = "base=" + base + "&target=" + target;

        // Get the output stream of the connection
        OutputStream os = conn.getOutputStream();

        // Write the parameters to the output stream as bytes
        os.write(params.getBytes());

        // Flush the stream to ensure all data is sent
        os.flush();

        // Read the response from the server using a BufferedReader
        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

        // Variable to hold each line of the response
        String line;

        // Read and print each line from the server's response
        while ((line = in.readLine()) != null) {
            System.out.println(line);
        }

        // Close the input stream
        in.close();
    }
}
