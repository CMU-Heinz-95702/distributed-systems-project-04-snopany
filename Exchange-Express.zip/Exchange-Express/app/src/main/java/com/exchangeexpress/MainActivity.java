package com.exchangeexpress;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * {@code MainActivity} is the main entry point of the Android app.
 * <p>
 * It provides a UI for users to input base and target currencies, fetches the exchange rate
 * via a network call using the {@link GetExchangeRate} helper class, and displays the result.
 * </p>
 *
 * @author Shreyas Nopany
 * Andrew ID - snopany
 */
public class MainActivity extends AppCompatActivity {

    // Input field for the base currency (e.g., USD)
    EditText baseCurrencyInput;

    // Input field for the target currency (e.g., EUR)
    EditText targetCurrencyInput;

    // Button to trigger the exchange rate fetch
    Button fetchButton;

    // TextView to display the result or error messages
    TextView resultView;

    /**
     * Called when the activity is starting. Sets up the UI and event handlers.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down,
     *                           this Bundle contains the data it most recently supplied.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Call the superclass method and initialize the activity
        super.onCreate(savedInstanceState);

        // Set the layout defined in activity_main.xml
        setContentView(R.layout.activity_main);

        // Link the base currency EditText with its corresponding UI element
        baseCurrencyInput = findViewById(R.id.baseInput);

        // Link the target currency EditText with its corresponding UI element
        targetCurrencyInput = findViewById(R.id.targetInput);

        // Link the fetch button with its corresponding UI element
        fetchButton = findViewById(R.id.fetchBtn);

        // Link the TextView where results or errors will be displayed
        resultView = findViewById(R.id.resultView);

        // Set an OnClickListener to the button to handle click events
        fetchButton.setOnClickListener(view -> {

            // Get and trim the user input for base currency
            String base = baseCurrencyInput.getText().toString().trim();

            // Get and trim the user input for target currency
            String target = targetCurrencyInput.getText().toString().trim();

            // Check if either input field is empty
            if (base.isEmpty() || target.isEmpty()) {
                // Show a message prompting the user to fill both fields
                resultView.setText("Please enter both base and target currencies.");
                return;
            }

            // Start an asynchronous task to fetch exchange rate
            new GetExchangeRate(MainActivity.this, base, target, new GetExchangeRate.Callback() {

                // Called when the result is successfully retrieved
                @Override
                public void onResult(String result) {
                    // Display the exchange rate result in the TextView
                    resultView.setText(result);
                }

                // Called when an error occurs during the request
                @Override
                public void onError(Exception e) {
                    // Display an error message
                    resultView.setText("Error! Check currency code or try again later.");
                }

            }).execute(); // Execute the async task
        });
    }
}
