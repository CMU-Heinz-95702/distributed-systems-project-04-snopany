package org.ds.exchangeserver;

import com.mongodb.client.FindIterable;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * {@code DashboardServlet} is a servlet that handles GET requests to the `/dashboard` endpoint.
 * <p>
 * It pulls log data from a MongoDB collection, aggregates stats like total requests,
 * most common currency pairs, and detailed logs, and then forwards the data to a JSP page for rendering.
 * </p>
 *
 * <p>Example data includes:
 * <ul>
 *     <li>Total number of exchange rate requests</li>
 *     <li>Top requested base-target currency pairs</li>
 *     <li>Request logs including time, rate, device, and IP</li>
 * </ul>
 * </p>
 *
 * @author Shreyas Nopany
 * Andrew ID - snopany
 */
@WebServlet("/dashboard")
// Declares this servlet to handle requests made to /dashboard
public class DashboardServlet extends HttpServlet {

    // Reference to the database service that accesses the MongoDB collection
    private final DatabaseService databaseService = new DatabaseService();

    /**
     * Handles HTTP GET requests and prepares dashboard statistics.
     *
     * @param req  The HTTP request from the client.
     * @param resp The HTTP response to be sent back.
     * @throws ServletException In case of servlet dispatch errors.
     * @throws IOException      If an I/O error occurs.
     */
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // Retrieve all log documents from the MongoDB collection
        FindIterable<Document> docs = databaseService.getCollection().find();

        // Initialize counter for total requests
        int totalRequests = 0;

        // Map to store counts of each unique base → target currency pair
        Map<String, Integer> pairCounts = new HashMap<>();

        // List to hold each individual request log for display
        List<Map<String, String>> logs = new ArrayList<>();

        // Iterate over each log document
        for (Document doc : docs) {

            // Increment total request count
            totalRequests++;

            // Extract base and target currency values
            String base = doc.getString("base_currency");
            String target = doc.getString("target_currency");

            // Combine base and target into a key like "USD → EUR"
            String pairKey = base + " → " + target;

            // Increment count for this currency pair
            pairCounts.put(pairKey, pairCounts.getOrDefault(pairKey, 0) + 1);

            // Extract additional fields from the document
            String timestamp = doc.getString("timestamp");
            String device = doc.getString("device_info");
            String apiResp = doc.getString("api_response");
            String clientIp = doc.getString("client_ip");

            // Initialize rate as placeholder
            String rate = "-";

            // Attempt to parse the rate from the API response JSON
            if (apiResp != null && apiResp.contains("rate")) {
                try {
                    rate = new org.json.JSONObject(apiResp).get("rate").toString();
                } catch (Exception e) {
                    // Handle parse error by setting rate to "error"
                    rate = "error";
                }
            }

            // Create a row representing a single log entry
            Map<String, String> row = new HashMap<>();
            row.put("timestamp", timestamp);
            row.put("base", base);
            row.put("target", target);
            row.put("rate", rate);
            row.put("device", device);
            row.put("ip", clientIp != null ? clientIp : "-");

            // Add the row to the list of logs
            logs.add(row);
        }

        // Convert the currency pair count map to a sorted list
        List<Map.Entry<String, Integer>> topPairs = new ArrayList<>(pairCounts.entrySet());

        // Sort pairs by descending order of request count
        topPairs.sort((a, b) -> b.getValue() - a.getValue());

        // Limit to top 5 pairs if there are more
        if (topPairs.size() > 5) topPairs = topPairs.subList(0, 5);

        // Set request attributes to be used by dashboard.jsp
        req.setAttribute("totalRequests", totalRequests);
        req.setAttribute("topPairs", topPairs);
        req.setAttribute("logs", logs);

        // Forward the request to the dashboard JSP page for rendering
        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
    }
}
