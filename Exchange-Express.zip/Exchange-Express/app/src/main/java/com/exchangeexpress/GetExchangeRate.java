package com.exchangeexpress;

import android.app.Activity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * {@code GetExchangeRate} handles making a network POST request to an exchange rate API.
 * <p>
 * It sends base and target currency data to the server, parses the JSON response,
 * and delivers the result asynchronously back to the UI via a {@link Callback}.
 * </p>
 *
 * @author Shreyas Nopany
 * Andrew ID - snopany
 */
public class GetExchangeRate {

    // Reference to the Activity, needed for UI thread callbacks
    private final Activity activity;

    // Callback interface to return results or errors
    private final Callback callback;

    // The base currency for exchange (e.g., USD)
    private final String baseCurrency;

    // The target currency for exchange (e.g., EUR)
    private final String targetCurrency;

    /**
     * Interface for receiving success or error callback from this task.
     */
    public interface Callback {
        // Called when exchange rate retrieval succeeds
        void onResult(String result);

        // Called when an error occurs during the process
        void onError(Exception e);
    }

    /**
     * Constructs the GetExchangeRate task with required input and callback.
     *
     * @param activity       The activity to post results back to the UI.
     * @param baseCurrency   The base currency code.
     * @param targetCurrency The target currency code.
     * @param callback       Callback to return the result or error.
     */
    public GetExchangeRate(Activity activity, String baseCurrency, String targetCurrency, Callback callback) {
        // Initialize class members
        this.activity = activity;
        this.baseCurrency = baseCurrency;
        this.targetCurrency = targetCurrency;
        this.callback = callback;
    }

    /**
     * Starts the asynchronous exchange rate fetch operation in a background thread.
     */
    public void execute() {
        // Launch a background thread for network operation
        new Thread(() -> {
            try {
                // Fetch the exchange rate (may throw an exception)
                String result = fetchRate();

                // Post the result back to the UI thread
                activity.runOnUiThread(() -> callback.onResult(result));
            } catch (Exception e) {
                // Post any error back to the UI thread
                activity.runOnUiThread(() -> callback.onError(e));
            }
        }).start(); // Start the background thread
    }

    /**
     * Performs the HTTP POST request and parses the JSON response.
     *
     * @return A formatted string with the exchange rate.
     * @throws Exception If any network or parsing error occurs.
     */
    private String fetchRate() throws Exception {

        // URL of the backend server endpoint
        String serverUrl = "https://special-umbrella-v6rv9g65xpxg2w67q-8080.app.github.dev/" + "express";

        // Create a URL object for the server endpoint
        URL url = new URL(serverUrl);

        // Open an HTTP connection to the URL
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // Set the HTTP method to POST
        conn.setRequestMethod("POST");

        // Enable sending data in the request body
        conn.setDoOutput(true);

        // Set the request content type to form URL-encoded
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        // Write the POST parameters to the request body
        PrintWriter writer = new PrintWriter(new OutputStreamWriter(conn.getOutputStream()));
        writer.write("base=" + baseCurrency + "&target=" + targetCurrency);
        writer.flush(); // Flush the writer to ensure all data is sent
        writer.close(); // Close the writer

        // Get the HTTP response code from the server
        int responseCode = conn.getResponseCode();

        // Throw an error if the response is not 200 OK
        if (responseCode != HttpURLConnection.HTTP_OK) {
            throw new RuntimeException("HTTP error code: " + responseCode);
        }

        // Read the server's response using a buffered reader
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;

        // Read response line-by-line
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        // Parse the response string into a JSON object
        JSONObject json = new JSONObject(response.toString());

        // Return the extracted exchange rate in a formatted string
        return "Exchange Rate: " + json.getDouble("rate");
    }
}
