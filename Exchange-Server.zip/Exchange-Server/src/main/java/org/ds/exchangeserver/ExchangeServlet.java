package org.ds.exchangeserver;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * {@code ExchangeServlet} is a Java servlet that handles HTTP POST requests to the `/express` endpoint.
 * <p>
 * It retrieves exchange rates for a given base and target currency using the CoinAPI service.
 * It also logs each request with metadata such as IP address, User-Agent, and full API response.
 * </p>
 *
 * <p>This servlet expects two form parameters: <b>base</b> and <b>target</b>, corresponding to currency codes.</p>
 *
 * @author Shreyas Nopany
 * Andrew ID - snopany
 */
@WebServlet("/express")
// Declares this servlet to respond to requests made to /express
public class ExchangeServlet extends HttpServlet {

    // API key to access the CoinAPI service
    private static final String API_KEY = "3fc05de6-c4a7-429a-b5ec-d66ca20ffdbb";

    // Instance of a logging service to save request metadata to a database
    private final DatabaseService logger = new DatabaseService();

    /**
     * Handles POST requests for currency exchange rate retrieval and logging.
     *
     * @param req  The HTTP request from the client, containing base and target currency.
     * @param resp The HTTP response to be sent back to the client, including the exchange rate or error.
     * @throws ServletException In case of servlet configuration or execution errors.
     * @throws IOException      If an input or output exception occurs.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // Extract the base currency parameter from the request
        String base = req.getParameter("base");

        // Extract the target currency parameter from the request
        String target = req.getParameter("target");

        // Extract User-Agent header to identify client device/browser
        String userAgent = req.getHeader("User-Agent");

        // Extract client IP address
        String clientIp = req.getRemoteAddr();

        // Print base and target currency for debugging
        System.out.println("[Request] base = " + base + ", target = " + target);

        // Print User-Agent for debugging
        System.out.println("[Request] User-Agent: " + userAgent);

        // Print client IP for debugging
        System.out.println("[Request] IP: " + clientIp);

        // Validate that both parameters are provided
        if (base == null || target == null) {
            // Send a 400 Bad Request error if parameters are missing
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameters");
            return;
        }

        // Construct the API URL using the base and target currencies
        String apiUrl = String.format("https://rest.coinapi.io/v1/exchangerate/%s/%s", base, target);

        try {
            // Open a connection to the external CoinAPI URL
            HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();

            // Set the HTTP method to GET
            conn.setRequestMethod("GET");

            // Add API key header for authentication
            conn.setRequestProperty("X-CoinAPI-Key", API_KEY);

            // Get the response code (optional; can be used for error handling)
            int responseCode = conn.getResponseCode();

            // Read the response from the input stream
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            // Use a StringBuilder to collect the full response
            StringBuilder result = new StringBuilder();
            String line;

            // Read response line-by-line and append to result
            while ((line = in.readLine()) != null) {
                result.append(line);
            }

            // Close the input stream after reading is complete
            in.close();

            // Print raw response from CoinAPI to the console
            System.out.println("[CoinAPI Response] " + result);

            // Parse the response string as a JSON object
            JSONObject json = new JSONObject(result.toString());

            // Extract the "rate" value from the JSON response
            double rate = json.getDouble("rate");

            // Log the request with metadata and full API response
            logger.logRequest(base, target, json.toString(), userAgent, clientIp);

            // Set the response content type to JSON
            resp.setContentType("application/json");

            // Get a writer to send the JSON response back to the client
            PrintWriter out = resp.getWriter();

            // Write the exchange rate as a JSON object
            out.print(new JSONObject().put("rate", rate));

            // Ensure all content is sent to the client
            out.flush();

        } catch (Exception e) {
            // Print any error message to the console
            System.out.println("[Error] " + e.getMessage());

            // Print full stack trace for debugging
            e.printStackTrace();

            // Send a 500 Internal Server Error response to the client
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to fetch exchange rate");
        }
    }
}
